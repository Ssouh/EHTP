<?php
$id = $_GET['idd'];


$pdo = new PDO(
    "mysql:host=localhost;dbname=ehtpgi",
    "root",
    ""
);
$sql  = "DELETE FROM users WHERE id=$id";

$pdo->exec($sql);

header("location:index.php");
