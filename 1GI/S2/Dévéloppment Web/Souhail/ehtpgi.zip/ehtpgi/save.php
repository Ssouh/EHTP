<?php
$id = $_GET['idd'];
$email = $_GET['mail'];
$password = $_GET['pass'];

$pdo = new PDO(
    "mysql:host=localhost;dbname=ehtpgi",
    "root",
    ""
);
$sql  = "UPDATE users SET email='$email', password='$password' WHERE id=$id";

$pdo->exec($sql);

header("location:index.php");
