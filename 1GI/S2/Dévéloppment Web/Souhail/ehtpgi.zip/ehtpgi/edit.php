<?php
$id = $_GET['idd'];


$pdo = new PDO(
    "mysql:host=localhost;dbname=ehtpgi",
    "root",
    ""
);
$sql  = "SELECT * FROM users WHERE id=$id";

$stmt = $pdo->query($sql);

$row = $stmt->fetch(PDO::FETCH_OBJ);

if(!$row) {
    header('location:index.php');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edition</title>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.css">
</head>
<body>
<div class="container">
    <h1>Edition de l'utilisateur</h1>
    <form action="save.php" >
        <input type="hidden" name="idd" value="<?= $id ?>"
               >
        <div class="form-group">
            <input type="text" name="mail" value="<?= $row->email ?>"
                   class="form-control">
        </div>
        <div class="form-group">
            <input type="text" name="pass" value="<?= $row->password ?>"
                   class="form-control">
        </div>
        <button class="btn btn-primary">Enregistrer</button>
    </form>
</div>
</body>
</html>
