<?php
$pdo = new PDO(
    "mysql:host=localhost;dbname=ehtpgi",
    "root",
    ""
);
$sql = "SELECT * FROM users";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC)

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gestion des utilisateurs</title>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.css">
</head>
<body>
<div class="container">
    <h1>Gestion des utilisateurs</h1>
    <form action="add.php" class="form-inline">
        <input type="text" name="mail" placeholder="Email" class="form-control">
        <input type="password" name="pass" placeholder="Password" class="form-control">
        <button class="btn btn-primary">Envoyer</button>
    </form>
    <table class="table table-striped table-bordered">
        <tr>
            <th>ID</th>
            <th>EMAIL</th>
            <th>PASSWORD</th>
            <th></th><th></th>
        </tr>
    <?php foreach ($rows as $row) :?>
       <tr>
            <td><?php echo $row['id'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['password'] ?></td>
           <td><a href="del.php?idd=<?= $row['id'] ?>" class="btn btn-danger">supprimer</a></td>
           <td><a href="edit.php?idd=<?= $row['id'] ?>" class="btn btn-warning">editer</a></td>
       </tr>
    <?php endforeach; ?>
    </table>
</div>

</body>
</html>