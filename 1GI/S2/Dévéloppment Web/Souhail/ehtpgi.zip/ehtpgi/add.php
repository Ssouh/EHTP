<?php
$email = $_GET['mail'];
$password = $_GET['pass'];

$pdo = new PDO(
    "mysql:host=localhost;dbname=ehtpgi",
    "root",
    ""
);
$sql  = "INSERT INTO users VALUES(null, '$email', '$password')";

$pdo->exec($sql);

header("location:index.php");
