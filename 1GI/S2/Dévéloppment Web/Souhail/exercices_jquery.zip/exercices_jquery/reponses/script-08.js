//  Chemin relatif : Pas de JS.
/**
 * Les fichiers générés doivent etre déposés dans le dossier ../files
 *    ../files/fr.xml
 *    ../files/fr-json.xml
 */











