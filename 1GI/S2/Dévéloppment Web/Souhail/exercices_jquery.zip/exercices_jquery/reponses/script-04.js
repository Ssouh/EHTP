//  Chemin relatif : reponses/script-04.js
//  Chemin relatif : files/user.json









