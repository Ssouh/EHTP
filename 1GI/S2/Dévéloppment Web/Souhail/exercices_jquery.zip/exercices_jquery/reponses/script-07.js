//  Chemin relatif : reponses/script-08.js










