//  chemin relatif : reponses/script-02.js








