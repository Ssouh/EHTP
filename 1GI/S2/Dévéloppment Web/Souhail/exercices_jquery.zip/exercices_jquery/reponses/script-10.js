//  Chemin relatif : ../reponses/script-10.js












