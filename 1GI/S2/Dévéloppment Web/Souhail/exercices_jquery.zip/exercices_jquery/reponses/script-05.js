//  Chemin relatif : reponses/script-05.js










