<?php

$id = $_GET['idd'];
$email = $_GET['email'];
$name = $_GET['name'];

$pdo = new PDO('mysql:host=localhost;dbname=ehtp', 'root', '');

$sql = "UPDATE users SET email='$email', name='$name' WHERE id=$id";

$ret = $pdo->exec($sql);

$error = $ret ? '' : '?error=l\'email doit être unique';

header("location:index.php$error");