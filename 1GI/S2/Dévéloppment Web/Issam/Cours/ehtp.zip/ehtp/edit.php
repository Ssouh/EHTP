<?php

$id = $_GET['idd'];

$pdo = new PDO('mysql:host=localhost;dbname=ehtp', 'root', '');

$sql = "SELECT * FROM users WHERE id=$id";

$stmt = $pdo->query($sql);

$row = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$row) :
    header("location:index.php");
    exit();
endif;
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Edition de l'utilisateur</h1>

<form action="save.php">
    <input type="hidden" name="idd" value="<?= $id ?>">
    <input type="text" name="email" value="<?= $row['email'] ?>">
    <input type="text" name="name" value="<?= $row['name'] ?>">
    <button>Enregistrer</button>
</form>
<hr>
</body>
</html>