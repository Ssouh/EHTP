<?php

$error = isset($_GET['error']) ? $_GET['error'] : false;

$pdo = new PDO('mysql:host=localhost;dbname=ehtp', 'root', '');

$sql = "SELECT * FROM users";

$stmt = $pdo->query($sql);

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>

<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .error {

        }
    </style>
</head>
<body>
<?php if($error) : ?>
    <div class="error">
        <?php echo $error ?>
    </div>
<?php endif; ?>
<h1>Liste des utilisateurs</h1>
<form action="add.php">
    <input type="text" name="email" placeholder="Email">
    <input type="text" name="name" placeholder="Name">
    <button>Envoyer</button>
</form>
<hr>
<table border="1" width="100%">
    <tr>
        <th>ID</th>
        <th>EMAIL</th>
        <th>NAME</th>
    </tr>
    <?php foreach ($rows as $row) : ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['name'] ?></td>
        <td><input type="button" value="Supprimer"
                   onclick="del(<?= $row['id'] ?>)"></td>
        <td><input type="button" value="Editer"
                   onclick="editer(<?= $row['id'] ?>)"></td>
    </tr>
    <?php endforeach; ?>
</table>
<script>
    function del(id) {
        if(window.confirm()) {
            location.href = "delete.php?idd=" + id;
        }
    }
    function editer(id) {
        location.href = "edit.php?idd=" + id;
    }
</script>
</body>
</html>