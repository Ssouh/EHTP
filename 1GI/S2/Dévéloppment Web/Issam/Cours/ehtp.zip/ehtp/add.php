<?php

$email = $_GET['email'];
$name = $_GET['name'];

$pdo = new PDO('mysql:host=localhost;dbname=ehtp', 'root', '');

$sql = "INSERT INTO users VALUES('', '$email', '$name')";

$ret = $pdo->exec($sql);

$error = $ret ? '' : '?error=l\'email doit être unique';

header("location:index.php$error");