#include "sesElements.h"

sesElements::sesElements()
{
    this->tete=nullptr;
    this->taille=0;
}
