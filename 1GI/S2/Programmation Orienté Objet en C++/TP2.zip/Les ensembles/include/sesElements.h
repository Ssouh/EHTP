#ifndef SESELEMENTS_H
#define SESELEMENTS_H


class sesElements
{
    public:
        sesElements();
        Noeud* tete;
        int taille;


    private:
};

#endif // SESELEMENTS_H
